﻿namespace ClinicManagement
{
    public class MetroFrame
    {
    }
}